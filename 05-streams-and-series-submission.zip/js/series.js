import { snode, sempty } from "../include/stream.js";
export function addSeries(s, t) {
    // TODO
    if (s.isEmpty()) {
        return t;
    }
    if (t.isEmpty()) {
        return s;
    }
    const head = s.head() + t.head();
    const tailFactory = () => addSeries(s.tail(), t.tail());
    return snode(head, tailFactory);
}
export function prodSeries(s, t) {
    // TODO
    if (s.isEmpty()) {
        return sempty();
    }
    function multiplySeries(s, t) {
        if (t.isEmpty()) {
            return sempty();
        }
        return snode(s.head() * t.head(), () => multiplySeries(s, t.tail()));
    }
    return snode(multiplySeries(s, t).head(), () => addSeries(multiplySeries(s, t).tail(), prodSeries(s.tail(), t)));
}
export function derivSeries(s) {
    // TODO
    function computeDerivative(s, n) {
        if (s.isEmpty()) {
            return sempty();
        }
        else {
            const head = n * s.head();
            const tail = computeDerivative(s.tail(), n + 1);
            return snode(head, () => tail);
        }
    }
    return computeDerivative(s.tail(), 1);
}
export function coeff(s, n) {
    // TODO
    function extractCoefficients(s, n, result) {
        if (n < 0 || s.isEmpty()) {
            return result;
        }
        else {
            result.push(s.head());
            return extractCoefficients(s.tail(), n - 1, result);
        }
    }
    return extractCoefficients(s, n, []);
}
export function evalSeries(s, n) {
    // TODO
    const coeffs = coeff(s, n);
    return (x) => {
        let sum = 0;
        let xPow = 1;
        for (let i = 0; i < coeffs.length; i++) {
            sum += coeffs[i] * xPow;
            xPow *= x;
        }
        return sum;
    };
}
export function applySeries(f, v) {
    // TODO
    return snode(v, () => applySeries(f, f(v)));
}
export function expSeries() {
    // TODO
    const getNextCoefficient = (() => {
        let currentFactorial = 1;
        let currentIndex = 0;
        return () => {
            currentIndex++;
            currentFactorial *= currentIndex;
            return 1 / currentFactorial;
        };
    })();
    return applySeries(getNextCoefficient, 1);
}
function calculateNextValue(init, coef) {
    let sum = 0;
    for (let i = 0; i < init.length; i++) {
        sum += init[i] * coef[i];
    }
    return sum;
}
function getNextValues(init, coef) {
    const nextValue = calculateNextValue(init, coef);
    return init.slice(1).concat(nextValue);
}
function generateRecurSeries(init, coef) {
    return snode(init[0], () => generateRecurSeries(getNextValues(init, coef), coef));
}
export function recurSeries(coef, init) {
    // TODO
    if (coef.length !== init.length) {
        throw new Error("The coef and init arrays must have the same length");
    }
    return generateRecurSeries(init, coef);
}
//# sourceMappingURL=series.js.map